var hello = "Hello World";
var num = 20;
var bools = true;

var myFunc = function () {
    return "Hi there I'm in a function";
}

var myObj = {
    thing1: "thing2"
}

module.exports = {
    hello,
    num,
    bools,
    myFunc,
    myObj
}