var { hello, num } = require('./intro.js');

console.log(hello, num);