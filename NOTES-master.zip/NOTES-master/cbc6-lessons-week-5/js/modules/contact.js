exports.contact = function () {
    return "Contact us at the number xxx-xxx-xxxx";
}

exports.funkLvl = 0;

exports.funk = function () {
    return ("Get on up");
}

exports.sing = "Get uppa";