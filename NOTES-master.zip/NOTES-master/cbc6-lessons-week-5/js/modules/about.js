// exports.funkLvl = 0;

// exports.funk = function () {
//     return ("Get on up");
// }

// exports.sing = "Get uppa";

exports.about = function () {
    return "The history of James Brown is long and exciting";
}