# Week 10 Cumulative test

The categories you will be graded on are technical skills and communication skills. The content of this test spans the entirety of the class so far.  You will have 5 hours to complete this and that should be enough time to attain a passing grade. There are 11 challenges in this test. To pass this test you will need to get 70 points. 

**The test is broken into 3 categories**
#### Frontend
- This section covers HTML, CSS, and JavaScript skills. There are 40 points possible for this section.

#### Backend
- This section covers NodeJS and SQL skills. There are 40 points possible for this section.

#### Communication
- This section covers Slack and Github skills. There are 30 points possible for this section.

#### Extra Credit
- There are 10 possible extra credit points. The problem will be located in one place and will be a single prompt in the code.

**Each problem is broken down into 10 points each**

#### Technical
- 1pt: Identified the problem's location
- 1pt: Identified the actual problem
- 1pt: Identified a solution
- 1pt: Implemented a solution

#### Documentation
- 1pt: Problem was clearly documented
- 1pt: Progress was clearly reported
- 1pt: Solution was clearly documented

#### Extra
- 1pt: Solution solved the prompt's question
- 1pt: Solution is scaleable
	- Easy for other developers to follow your work
- 1pt: Legibility, clear, concise