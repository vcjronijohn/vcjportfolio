window.onload = function () {
	document.querySelector(".container").appendChild(cards());
}