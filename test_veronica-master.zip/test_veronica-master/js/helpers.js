module.exports = {
	getUrlParams: function getUrlParameter(name, url) {
        // FOUND: https://davidwalsh.name/query-string-javascript
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(url);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
	}
}