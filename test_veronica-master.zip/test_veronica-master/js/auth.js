function authenticate (username, password) {
	var xhr = new XMLHttpRequest();

	xhr.onreadystatechange = function () {
		if(xhr.readyState === 4 && xhr.status === 200) {
			console.log(this.responseText);
		}
	}
	var req = (
		"/auth?username=" + 
		username + 
		"&password=" + 
		password  
	);
	xhr.open("GET", req, true);
	xhr.send();
}