window.onload = function () {
	document.getElementById("login").addEventListener("click", function (event) {
		event.preventDefault();

		var username = document.forms[0].username.value;
		var password = document.forms[0].password.value;

		validate(username, password);
	})
}

var validate = function (username, password) {
	authenticate(username, password);
}