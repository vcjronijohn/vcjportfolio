var config = require("./config");
var mysql = require("mysql");

module.exports = {
	checkAuth: function (username, password) {
		return new Promise (function (resolve, reject) {
			var result = username + "has authenticated";
			resolve(result);
			reject(error);
		});
	},
	getEmployees: function () {
		var sql /* =  Write SQL here */;
		var con = mysql.createConnection(config)
		con.connect(function(err) {
			if (err) throw err;
			con.query(sql, function (error, result) {
				if(error) throw error;
				console.log(result);
			});
		})
	},
	addUser: function (employee) {
		var sql = "INSERT INTO employees (name, details) VALUES ('"+ employee.name +"', '" + employee.detail + "');";
		var con = mysql.createConnection(config)
		con.connect(function (err) {
			if (err) throw err;
			con.query(sql, function (err, result) {
				if (err) throw new err;
				console.log("1 record inserted");
			});
		});
	}
}