function cards () {
	const cards = document.createElement("div");

	let i = 0;

	while(i < 6) {
		++i;

		const card = document.createElement("div"),
		img = document.createElement("img"),
		h3 = document.createElement("h3"),
		p = document.createElement("p");

		cards.classList.add("cards");
		card.classList.add("card");
		img.setAttribute("src", "../images/undraw_female_avatar_l3ey.png");
		h3.innerHTML = "Name";
		p.innerHTML = "Detail";


		card.appendChild(img);
		card.appendChild(h3);
		card.appendChild(p);
		cards.appendChild(card);
	}

	document.querySelector(".container").innerHTML = "";

	return cards;
}