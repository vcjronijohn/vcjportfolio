# Week 6

You work as the sole developer for a startup and one day you receive an email.
It is your boss who tells you that clients have been complaining about not being able to login.  She wants a markdown report of the bugs you found and the fixes you did by the end of the day.

*note*: I would recommend if you feel like you finished go and add new features, document them and try to get that promotion.