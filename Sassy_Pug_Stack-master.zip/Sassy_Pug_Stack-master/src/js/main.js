window.onload = () => {
	let div = document.createElement("div");
	div.innerHTML = "This was created with ES6 JS";
	document.body.appendChild(div);
}